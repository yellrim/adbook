﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace adbook
{

    public partial class Form2 : Form
    {
        int index = 0;      //프로그램이 끝날때까지 초기화 안됨
        MyInfo[] myinfoarray = new MyInfo[10];


        string[] myinfoarra4 = new string[10];
        int[] myinfoarray3 = new int[10];

        public class MyInfo
        {
            public string arrusername;
            public int arruserphone;
        }

        // 전역변수
        int input;

        String write = "검색할 이름 입력 : ";



        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            for(int i = 0; i < 10; i++)
            {
                myinfoarray[i] = new MyInfo();
            }

            main();

        }


        public void main()
        {
            Console.Clear();
            MainView();

            input = int.Parse(Console.ReadLine());

            Console.WriteLine("입력값 : " + input);

            if (input == 0)
            {
                Console.Clear();
                Test1();

            }
            else if (input == 1)
            {
                Console.Clear();
                Test2();
            }
            else if (input == 2)
            {
                Console.Clear();
                Test3();
            }
            else if (input == 3)
            {
                Console.Clear();
                Test4();
            }
            else if (input == 4)
            {
                Console.Clear();
                Test5();
            }
            else if (input == 5)
            {
                Console.Clear();
                Test6();
            }
            else if(input == 6)
            {
                Console.Clear();
                Test7();
            }else
            {

            }

            Console.Clear();

        }

        public void MainView()
        {
            Console.WriteLine("-----------------------");
            Console.WriteLine("0. 정보 입력");
            Console.WriteLine("1. 정보 검색");
            Console.WriteLine("2. 정보 수정");
            Console.WriteLine("3. 정보 삭제");
            Console.WriteLine("4. 전체 출력");
            Console.WriteLine("5. 파일에 저장");
            Console.WriteLine("6. 파일 불러오기");
            Console.WriteLine("7. 프로그램 종료");
            Console.WriteLine("-----------------------");
            Console.WriteLine("메뉴를 선택하세요");
        }

        public void Test1()
        {
            /*정보입력*/
            Console.WriteLine("--정보입력화면--");

            //Array.Resize(ref arrusername, arrusername.Length + 1);

            Console.Write("이름 입력 : ");
            myinfoarray[index].arrusername = Console.ReadLine();
            Console.Write("번호 입력 : ");
            myinfoarray[index].arruserphone = int.Parse(Console.ReadLine());

            //Console.WriteLine("입력후 Index : " + index + " 값 :" + arrusername[index]);

            index = index + 1;

            //전체 출력 
            Console.ReadLine();
            main();
        }

        public void Test2()
        {
            Test21(write);

            main();

        }
        public int Test21(String write)
        {
            /*
             * 검색함수
             * 검색값 = 배열안 값이 될때 까지 배열 반복
             * 검색값 = 배열안 값이 같으면 위치 추출 
             * 위치의 내용 출력
             */

            /*정보검색*/
            String searchinput;
            int checkCount = 0;
            int saveIndex = 0;


            Console.Write(write);
            searchinput = Console.ReadLine();


            for (int i = 0; i < index; i++) // 입력값을 저장한 배열의 길이 만큼 반복
            {
                if (searchinput == myinfoarray[i].arrusername)// 반복하다가 검색할 이름 == 저장된 이름이 같으면 실행
                {
                    //saveIndex[checkCount] = i; // 같은 데이터의 위치값 i를 배열에 삽입
                    saveIndex = i;
                    checkCount = checkCount + 1;  // 같은 데이터를 발견할때 카운팅
                }

            }

            if (checkCount > 0)  //검색결과 없음을 나타내기 위한 카운팅 조건
            {
                //for (int i = 0; i < checkCount; i++)
                //{
                    //Console.WriteLine("검색 결과 찾은위치 : " + saveIndex[i] + " 결과값 : " + arrusername[saveIndex[i]]);
                    Console.WriteLine("-----------------------");
                    Console.WriteLine("검색 결과 : ");
                    Console.WriteLine("이름 : " + myinfoarray[saveIndex].arrusername);
                    Console.WriteLine("번호 : " + myinfoarray[saveIndex].arruserphone);
                    //Console.WriteLine("전화 : ");
                    //Console.WriteLine("주소 : ");
                    Console.WriteLine("-----------------------");
              //  }
            }
            else
            {
                Console.WriteLine("결과 없음");
            }

            Console.ReadLine();
            return saveIndex;
        }


        /*
        * 수정함수
        * 검색 결과 값에 새로운 값을 대입해줌
        */

        public void Test3()
        {
            // 지역변수
            String write = "변경할 이름 입력 : ";



            /*정보수정*/
            int changeIndex = Test21(write);

            Console.WriteLine("-----------------------");
            Console.WriteLine("변경할 이름 : ");
            myinfoarray[changeIndex].arrusername = Console.ReadLine();
            Console.WriteLine("변경할 변호 : ");
            myinfoarray[changeIndex].arruserphone = int.Parse(Console.ReadLine());
            //Console.WriteLine("주소 : ");
            Console.WriteLine("-----------------------");

           // myinfoarray[changeIndex] = changInfo[changeIndex].changname;
            //myinfoarray[changeIndex] = changInfo[changeIndex].changphone;

            Console.ReadLine();
            main();
        }


        public void Test4()
        {
            String write = "삭제할 이름 입력 : ";
            int changeIndex = Test21(write);


            /*정보삭제*/
            myinfoarray[changeIndex].arrusername = string.Empty;
            myinfoarray[changeIndex].arruserphone = 0;

            Console.ReadLine();
            main();
        }

        public void Test5()
        {
            /*전체출력*/
            for (int i = 0; i < index; i++)
            {
                Console.WriteLine("-----------{0}------------", i);
                Console.WriteLine("이름 : " + myinfoarray[i].arrusername);
                Console.WriteLine("번호 : " + myinfoarray[i].arruserphone);
                Console.WriteLine("--------------------------");
            }

            Console.ReadLine();
            main();

        }

        public void Test6()
        {

            /*입력한거 파일에 저장*/
            StreamWriter writer;
            writer = File.CreateText(@"C:\test.txt");

            int saveindex = 0;
            for (int i = 0; i < index; i++)
            {
                if (!myinfoarray[i].arrusername.Equals(""))
                {
                    //writer.WriteLine("-----------{0}------------", saveindex);
                    writer.WriteLine("이름 : " + myinfoarray[i].arrusername + "   /번호 : " + myinfoarray[i].arruserphone);
                    //writer.WriteLine();
                    //writer.WriteLine("--------------------------");
                    //saveindex++;
                }
            }
            
            //저장될 string
            writer.Close();



            Console.ReadLine();
            main();

        }

        public void Test7()
        {
            /*입력한거 파일에 불러오기*/
            //type1
            string text = System.IO.File.ReadAllText(@"C:\test.txt");

            System.Console.WriteLine("Contents of WriteText.txt = {0}", text);

            //type2
            string[] lines = System.IO.File.ReadAllLines(@"C:\test.txt");

            System.Console.WriteLine("Contents of WriteLines2.txt = ");
            for (int i =0; i < lines.Length; i++)
            {
                Console.WriteLine(lines[i]);
            }

            foreach (string line in lines)
            {
                Console.WriteLine( line);
            }

            System.Console.ReadLine();
        }



    }
}