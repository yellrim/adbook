﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace adbook
{


    public partial class Form2 : Form
    {

        int input;
        public string name;

        public string[] arrusername;


        // public string phone;
        //public string addr;


        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //객체로 만들기
            //Info uesr_info = new Info();
            //uesr_info.name = name;
            //uesr_info.phone = phone;
            //uesr_info.addr = addr;


            arrusername = new string[10];


            main();

        }

        public void main()
        {

            Console.Clear();
            MainView();

            input = int.Parse(Console.ReadLine());

            Console.WriteLine("입력값 : " + input);

            if (input == 0)
            {
                Console.Clear();
                Test1();

            }
            else if (input == 1)
            {
                Console.Clear();
                Test2();
            }
            else if (input == 2)
            {
                Console.Clear();
                Test3();
            }
            else if (input == 3)
            {
                Console.Clear();
                Test4();
            }
            else if (input == 4)
            {
                Console.Clear();
                Test5();
            }
            else if (input == 5)
            {

            }

        }

        public void MainView()
        {
            Console.WriteLine("-----------------------");
            Console.WriteLine("0. 정보 입력");
            Console.WriteLine("1. 정보 검색");
            Console.WriteLine("2. 정보 수정");


            Console.WriteLine("3. 정보 삭제");
            Console.WriteLine("4. 전체 출력");
            Console.WriteLine("5. 프로그램 종료");
            Console.WriteLine("-----------------------");
            Console.WriteLine("메뉴를 선택하세요");
        }

        public void Test1()
        {
            //string[] arrusername = new string[10];
            /*정보입력*/
            Console.WriteLine("--정보입력화면--");

            Console.WriteLine("이름 입력 : "); name = Console.ReadLine();


            //arrusername[0] = name;

            // 배열에 저장해주는 코드 넣기
            for (int i = 0; i < 10; i++)
            {
                arrusername[i] = name;
            };


            //Console.WriteLine("전화 입력 : "); phone = Console.ReadLine();
            //Console.WriteLine("주소 입력 : "); addr = Console.ReadLine();

            Console.ReadLine();


            main();
        }
        public void Test2()
        {
            /*정보검색*/
            Console.WriteLine("이름 입력 : ");
            Console.ReadLine();
            Console.WriteLine("-----------------------");
            Console.WriteLine("이름 : ");
            //Console.WriteLine("전화 : ");
            //Console.WriteLine("주소 : ");
            Console.WriteLine("-----------------------");

            Console.ReadLine();


            main();
        }
        public void Test3()
        {
            /*정보수정*/
            Console.WriteLine("이름 입력 : ");
            Console.WriteLine("-----------------------");
            Console.WriteLine("이름 : ");
            //Console.WriteLine("전화 : ");
            //Console.WriteLine("주소 : ");
            Console.WriteLine("-----------------------");


            Console.ReadLine();
            main();
        }
        public void Test4()
        {
            /*정보삭제*/
            Console.WriteLine("이름 입력 : ");

            Console.ReadLine();
            main();
        }
        public void Test5()
        {
            /*전체출력*/
            Console.WriteLine("-----------0------------");
            Console.WriteLine("이름 : " + arrusername[0]);
            //Console.WriteLine("전화 : " + phone);
            //Console.WriteLine("주소 : " + addr);
            Console.WriteLine("-----------------------");

            Console.ReadLine();

            main();
        }

    }
}