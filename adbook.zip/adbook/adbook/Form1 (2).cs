﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adbook
{
    public partial class Form1 : Form
    {



        int test_01 = 1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


            int MAXMAX = 20;
            int a = Plus1(MAXMAX);
            string value2 = add();



            string  value3 = "aA";
            int value4 = 10;



            add2(value3, value4);

            Console.WriteLine(a);
        }


        void add2(string a, int b)
        {


        }


        string add()
        {
            string value = "hello" + "hi";

            return value;
        }



        int Plus1(int max)
        {
            int val = 0;

            for (int i = 0; i < max; i++)
            {

                val = val + i;
            }

            return val;
        }
    }
}
